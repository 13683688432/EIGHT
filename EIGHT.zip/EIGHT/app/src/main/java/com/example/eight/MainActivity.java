package com.example.eight;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置生成的视图信息 把内部视图类传进去
        setContentView(R.layout.activity_main);
        Button bt = findViewById(R.id.bt);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(new CustomView(MainActivity.this));     //这里直接进入CustomView类
            }
        });
    }
    //内部类中编写
    class CustomView extends View{


        //定义各个坐标的位置变量
        float startX,startY,stopX,stopY;

        public CustomView(Context context) {
            super(context);
        }
        //画的方法
        @Override
        protected void onDraw(Canvas canvas) {
            //创建画笔对象
            Paint paint = new Paint();
            //设置画笔的颜色
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(10);
            //画直线的方法，把各个点的坐标值传进去
            canvas.drawLine(startX, startY, stopX, stopY, paint);
            super.onDraw(canvas);
        }
        //点击事件
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            //选择点击动作
            switch (event.getAction()){
                //按下
                case MotionEvent.ACTION_DOWN:
                    //设置起点的坐标值
                    startX = event.getX();
                    startY = event.getY();      //只有一个起始点时不刷新
                    break;
                //移动
                case MotionEvent.ACTION_MOVE:
                    // 设置移动时重点坐标的值
                    stopX = event.getX();
                    stopY = event.getY();
                    //强制刷新视图
                    invalidate();
                    break;
                //抬起
                case MotionEvent.ACTION_UP:
                    //获取抬起的坐标值
                    stopX = event.getX();
                    stopY = event.getY();
                    //强制刷新视图
                    invalidate();
                    break;
            }
            return true;
        }

    }

}